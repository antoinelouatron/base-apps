"""
date: 2024-02-26
"""

from .year import GenerateWeeks
from .events import *
from .colles import *