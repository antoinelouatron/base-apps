Add settings:
 * ROOT_URLCONF
 * DATABASE
 * TEMPLATES["OPTIONS"].append(...)
 * static and media path

Add asset-map.json and set setting accordingly